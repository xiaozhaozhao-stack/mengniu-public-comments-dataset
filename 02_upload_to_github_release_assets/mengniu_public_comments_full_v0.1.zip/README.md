# Mengniu Comments Cleaning Sample

这个仓库包用于展示评论数据清洗流程，并包含完整的清洗后评价数据。

注意：本包不包含原始未清洗数据文件，只包含清洗后的 `processed` 结果。

## Contents

- `data/processed/`: 完整清洗后结果，包含 62 个与原始文件同名的评论文件。
- `data/processed/all_comments_merged.txt`: 全部清洗评论合并去重后的文件。
- `data/processed/cantonese_traditional_comments.txt`: 从清洗结果中单独抽出的粤语/港式繁体/繁体字评论，便于检查这些内容是否保留。
- `data/processed/processing_report.csv`: 每个原始 `.txt` 文件的清洗统计，输出路径已改为包内相对路径。
- `data/processed/sample_comments.txt`: 200 条清洗后的评论样本。
- `data/json_comments/`: 从子文件夹 JSON API 响应中抽取并清洗后的评论结果。
- `data/json_comments/by_folder/`: 按原始 JSON 所在子文件夹分组的清洗评论文件。
- `data/json_comments/all_json_comments_merged.txt`: 全部 JSON 评论合并去重后的文件。
- `data/json_comments/cantonese_traditional_json_comments.txt`: JSON 评论中保留下来的粤语/港式繁体/繁体字评论。
- `data/json_comments/json_comment_processing_report.csv`: JSON 评论抽取与清洗报告。
- `data/cantonese_traditional_comments.txt`: 粤语/港式繁体/繁体字评论的便捷副本。
- `data/sample_comments.txt`: 样本文件的便捷副本。
- `data/processing_report.csv`: 报告文件的便捷副本。
- `scripts/process_comments.py`: 评论清洗脚本，仅使用 Python 标准库。
- `scripts/extract_json_comments.py`: JSON 评论抽取与清洗脚本，仅使用 Python 标准库。

## Cleaning Rules

脚本会按行处理 `.txt` 评论数据，并执行以下清洗：

- 去除空行
- 去除重复评论
- 去除页面杂项，例如展开、回复、全部、好评、差评、客服、加入购物车等
- 去除手机号、链接、疑似用户 ID、地址等个人信息
- 每条评论一行保存
- 保留中文评论正文，包括原始数据中已有的粤语、港式繁体和繁体字表达

## Reproduce

把原始 `.txt` 评论文件放在一个目录下，然后运行：

```bash
python scripts/process_comments.py "path/to/raw/comment/folder"
```

脚本会在原始目录下创建 `processed` 文件夹，并生成：

- 每个原始文件对应的同名清洗文件
- `processing_report.csv`
- `all_comments_merged.txt`
- `sample_comments.txt`

## Data Notice

原始评论文件和原始 JSON API 响应体量较大且未经清洗，不建议提交到 GitHub。本包已经包含从 TXT 和 JSON 中抽取清洗后的完整评论结果，可直接用于展示、复核和后续分析。

JSON 处理不是原样上传 API 响应，而是抽取 `commentData`、`tagCommentContent`、`commentContent`、`eval_content`、`comment`、`content` 等评论字段，并过滤页面标签、商家回复、用户 ID、链接、手机号等无关或敏感内容。
