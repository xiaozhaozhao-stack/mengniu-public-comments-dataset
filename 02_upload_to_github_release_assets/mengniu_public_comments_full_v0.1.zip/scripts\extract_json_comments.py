from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from process_comments import clean_candidate, dedupe_key  # noqa: E402


HIGH_CONFIDENCE_KEYS = {
    "commentData",
    "tagCommentContent",
    "commentContent",
    "eval_content",
    "eval_content_input",
    "comment",
}

MEDIUM_CONFIDENCE_KEYS = {
    "content",
}

FALLBACK_KEYS = HIGH_CONFIDENCE_KEYS | MEDIUM_CONFIDENCE_KEYS

JSON_STRING_RE = re.compile(
    r'"(?P<key>commentData|tagCommentContent|commentContent|eval_content|eval_content_input|comment|content)"\s*:\s*"(?P<value>(?:\\.|[^"\\])*)"',
    re.S,
)

COMMENT_HINT_RE = re.compile(
    r"(牛奶|奶|好喝|难喝|口感|味道|奶香|香浓|浓郁|包装|物流|发货|送货|快递|收到|日期|新鲜|"
    r"回购|购买|喜欢|满意|推荐|划算|实惠|便宜|营养|蛋白|孩子|小孩|老人|破损|漏|服务|"
    r"順滑|濃|購|買|實惠|不錯|愛喝|包裝|發货|經常|飲|好飲)"
)

DAIRY_HINT_RE = re.compile(
    r"(牛奶|鲜奶|鮮奶|純奶|纯奶|純牛|纯牛|奶香|奶味|酸奶|酸乳|牛乳|乳蛋白|乳糖|巴氏|生牛乳|"
    r"特仑苏|特侖蘇|蒙牛|伊利|金典|悦鲜活|悅鮮活|黑白奶|蛋白|补钙|補鈣|鈣|好飲|飲)"
)

MERCHANT_REPLY_RE = re.compile(
    r"(尊敬的顾客|尊敬的客戶|顾客您好|顧客您好|叮小咚回复|商家回复|店家回复|商家回应|"
    r"感謝您嘅反映|感谢您.*反馈|對於為您造成|对于为您造成|小編喺度|小编|"
    r"客服同事|客服代表|根據系統紀錄|根据系统记录|退換貨品申請|退换货品申请|"
    r"我哋會將您嘅意見|我们会将您的意见|相關部門|相关部门|電郵回覆|邮件回复|"
    r"訊息中心|信息中心|個案編號|个案编号|安排退款|安排退回)"
)

UNRELATED_PRODUCT_RE = re.compile(
    r"(苹果|蘋果|冰糖心|轮胎|輪胎|换胎|換胎|洗衣机|冰箱|空调|家电|储物|儲物|电机|電機|省电|省電|续航|續航|"
    r"师傅安装|師傅安裝|安装师傅|安裝師傅|上门安装|上門安裝|颜色挺漂亮|太喜欢这颜色)"
)

HK_TRAD_RE = re.compile(
    r"(唔|咁|嘅|佢|哋|冇|喺|嚟|畀|俾|啲|咗|係|乜|嘢|咩|吖|囉|喇|噃|"
    r"[買賣評價貨裝濃營養這裡個開關體點後會經過還應與為給無來時實發補爛購兩級覺兒準滿種產質處風萬說嗎貴愛鮮])"
)

INVALID_FILENAME_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def read_text(path: Path) -> str:
    data = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "gb18030", "utf-16"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def safe_name(name: str) -> str:
    cleaned = INVALID_FILENAME_RE.sub("_", name).strip(" .")
    if not cleaned:
        cleaned = "root"
    if len(cleaned) <= 96:
        return cleaned
    digest = hashlib.sha1(name.encode("utf-8")).hexdigest()[:10]
    return f"{cleaned[:80]}__{digest}"


def top_folder_for(path: Path, base: Path) -> str:
    rel = path.relative_to(base)
    if len(rel.parts) <= 1:
        return "_root"
    return rel.parts[0]


def decode_json_string(raw: str) -> str:
    try:
        return json.loads(f'"{raw}"')
    except Exception:
        return raw


def should_keep_json_candidate(cleaned: str, key: str) -> bool:
    if not cleaned:
        return False
    if MERCHANT_REPLY_RE.search(cleaned):
        return False
    if UNRELATED_PRODUCT_RE.search(cleaned) and not DAIRY_HINT_RE.search(cleaned):
        return False
    if key in HIGH_CONFIDENCE_KEYS:
        return True
    if key in MEDIUM_CONFIDENCE_KEYS:
        cjk_count = len(re.findall(r"[\u4e00-\u9fff]", cleaned))
        if cjk_count >= 6 and COMMENT_HINT_RE.search(cleaned) and DAIRY_HINT_RE.search(cleaned):
            return True
        if HK_TRAD_RE.search(cleaned) and cjk_count >= 4 and DAIRY_HINT_RE.search(cleaned):
            return True
    return False


def extract_from_json_object(obj: Any, results: list[tuple[str, str]], field_counts: Counter[str]) -> None:
    if isinstance(obj, dict):
        for key, value in obj.items():
            if str(key).lower() in {"reply", "replies", "replylist", "reply_list", "replyinfo", "reply_info"}:
                continue
            if key in HIGH_CONFIDENCE_KEYS or key in MEDIUM_CONFIDENCE_KEYS:
                if isinstance(value, str):
                    results.append((key, value))
                    field_counts[key] += 1
            extract_from_json_object(value, results, field_counts)
    elif isinstance(obj, list):
        for item in obj:
            extract_from_json_object(item, results, field_counts)


def extract_candidates(path: Path, field_counts: Counter[str]) -> tuple[list[tuple[str, str]], bool]:
    text = read_text(path)
    try:
        obj = json.loads(text)
    except Exception:
        candidates: list[tuple[str, str]] = []
        for match in JSON_STRING_RE.finditer(text):
            key = match.group("key")
            value = decode_json_string(match.group("value"))
            candidates.append((key, value))
            field_counts[key] += 1
        return candidates, False

    candidates: list[tuple[str, str]] = []
    extract_from_json_object(obj, candidates, field_counts)
    return candidates, True


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: python extract_json_comments.py <source_folder> <output_folder>", file=sys.stderr)
        return 2

    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    if not source.is_dir():
        print(f"Source folder not found: {source}", file=sys.stderr)
        return 2

    by_folder: dict[str, list[str]] = defaultdict(list)
    by_folder_seen: dict[str, set[str]] = defaultdict(set)
    source_stats: dict[str, dict[str, int]] = defaultdict(
        lambda: {
            "json_files": 0,
            "json_parse_ok": 0,
            "raw_candidates": 0,
            "cleaned_candidates": 0,
            "duplicate_removed": 0,
        }
    )
    field_counts: Counter[str] = Counter()

    for path in sorted(source.rglob("*.json")):
        folder = top_folder_for(path, source)
        stats = source_stats[folder]
        stats["json_files"] += 1

        candidates, parse_ok = extract_candidates(path, field_counts)
        stats["json_parse_ok"] += int(parse_ok)
        stats["raw_candidates"] += len(candidates)

        for key, value in candidates:
            for part in str(value).splitlines():
                cleaned = clean_candidate(part)
                if not cleaned or not should_keep_json_candidate(cleaned, key):
                    continue
                stats["cleaned_candidates"] += 1
                dkey = dedupe_key(cleaned)
                if not dkey:
                    continue
                if dkey in by_folder_seen[folder]:
                    stats["duplicate_removed"] += 1
                    continue
                by_folder_seen[folder].add(dkey)
                by_folder[folder].append(cleaned)

    output.mkdir(parents=True, exist_ok=True)
    by_folder_dir = output / "by_folder"
    by_folder_dir.mkdir(parents=True, exist_ok=True)

    global_seen: set[str] = set()
    merged: list[str] = []
    hk_trad: list[str] = []
    report_rows: list[dict[str, object]] = []

    for folder in sorted(source_stats):
        comments = by_folder.get(folder, [])
        file_name = f"{safe_name(folder)}.txt"
        out_path = by_folder_dir / file_name
        out_path.write_text("\n".join(comments) + ("\n" if comments else ""), encoding="utf-8")

        for comment in comments:
            dkey = dedupe_key(comment)
            if dkey and dkey not in global_seen:
                global_seen.add(dkey)
                merged.append(comment)
                if HK_TRAD_RE.search(comment):
                    hk_trad.append(comment)

        stats = source_stats[folder]
        report_rows.append(
            {
                "原始文件夹": folder,
                "JSON文件数": stats["json_files"],
                "可解析JSON数": stats["json_parse_ok"],
                "抽取候选评论数": stats["raw_candidates"],
                "清洗后候选评论数": stats["cleaned_candidates"],
                "文件夹内去重删除数量": stats["duplicate_removed"],
                "输出文件路径": str(out_path),
            }
        )

    (output / "all_json_comments_merged.txt").write_text(
        "\n".join(merged) + ("\n" if merged else ""), encoding="utf-8"
    )
    (output / "sample_json_comments.txt").write_text(
        "\n".join(merged[:200]) + ("\n" if merged[:200] else ""), encoding="utf-8"
    )
    (output / "cantonese_traditional_json_comments.txt").write_text(
        "\n".join(hk_trad) + ("\n" if hk_trad else ""), encoding="utf-8"
    )

    report_path = output / "json_comment_processing_report.csv"
    with report_path.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "原始文件夹",
            "JSON文件数",
            "可解析JSON数",
            "抽取候选评论数",
            "清洗后候选评论数",
            "文件夹内去重删除数量",
            "输出文件路径",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(report_rows)

    field_report_path = output / "json_comment_field_report.csv"
    with field_report_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["field", "raw_value_count"])
        for key, count in field_counts.most_common():
            writer.writerow([key, count])

    print(f"json_files={sum(r['JSON文件数'] for r in report_rows)}")
    print(f"source_folders={len(report_rows)}")
    print(f"folder_output_files={len(list(by_folder_dir.glob('*.txt')))}")
    print(f"cleaned_candidates={sum(r['清洗后候选评论数'] for r in report_rows)}")
    print(f"merged_unique_comments={len(merged)}")
    print(f"hk_trad_comments={len(hk_trad)}")
    print(f"output={output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
