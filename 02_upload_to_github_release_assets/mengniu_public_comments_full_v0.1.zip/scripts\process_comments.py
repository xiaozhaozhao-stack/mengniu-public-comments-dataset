from __future__ import annotations

import csv
import re
import sys
from pathlib import Path


ENCODINGS = ("utf-8-sig", "utf-8", "gb18030", "utf-16", "utf-16-le", "utf-16-be")

PAGE_EXACT_TERMS = {
    "展开",
    "回复",
    "全部",
    "好评",
    "差评",
    "客服",
    "进店",
    "购物车",
    "加入购物车",
    "立即购买",
    "去抢购",
    "图/视频",
    "视频",
    "图片",
    "综合",
    "最新",
    "有用",
    "追评",
    "商品评价",
    "被折叠评价",
    "折叠评价",
    "达人秀",
    "官方正品",
    "正品保障",
    "售后无忧",
    "运费险",
    "免运费",
    "专享价",
    "旗舰店",
    "品牌授权",
    "抖音商城App专享",
    "抖音商城官方认证",
    "店铺销量超99%同行",
    "不支持7天无理由",
    "品牌儿童乳制品",
}

DEFAULT_REVIEW_TERMS = {
    "此用户觉得商品很好，给出了好评",
    "此用户未填写评价内容",
    "该用户觉得商品很好，给出了好评",
    "用户未填写评价内容",
}

PAGE_CUT_MARKERS = (
    " 旗舰店 ",
    " 客服 ",
    " 购物车 ",
    " 加入购物车",
    " 正品保障",
    " 售后无忧",
    " 运费险",
    " 去抢购",
    " 立即购买",
    " 抖音商城",
    " 京东",
    " 拼多多",
    " 淘宝",
    " 商品评价",
    " 适用人群",
    " 贮存条件",
    " 饮品种类",
    " 是否进口",
    " 包装类型",
    " 食品生产许可证",
    " 生产企业名称",
    " 营养成分表",
    " 配料表",
    " 为你挑选",
    " 达人秀",
    " 图/视频",
    " 已售",
    " 人正在看",
    " 人逛过",
    " 人感兴趣",
    " 预计",
    " 发货",
    " 免运费",
    " 品牌授权",
    " 店铺销量",
    " 回头客",
    " 已买",
)

PAGE_NOISE_TERMS = (
    "评价",
    "全部",
    "图/视频",
    "追评",
    "好评",
    "差评",
    "综合",
    "最新",
    "为你挑选",
    "真实",
    "有帮助",
    "客服",
    "购物车",
    "正品保障",
    "售后无忧",
    "运费险",
    "专享价",
    "旗舰店",
    "官方认证",
    "官方正品",
    "去抢购",
    "立即购买",
    "已售",
    "入会领",
    "满",
    "减",
    "抖音商城",
    "京东",
    "拼多多",
    "淘宝",
    "商品评价",
    "适用人群",
    "贮存条件",
    "饮品种类",
    "是否进口",
    "包装类型",
    "食品生产许可证",
    "生产企业",
    "营养成分表",
    "配料表",
    "达人秀",
    "人正在看",
    "人逛过",
    "人感兴趣",
    "发货",
    "免运费",
    "回头客",
    "已买",
    "店铺销量",
    "品牌授权",
    "极速退款",
    "7天无理由",
    "送达",
    "专享",
    "分享",
    "点赞",
    "已购",
    "买过",
    "超赞",
)

COMMENT_HINTS = (
    "包装",
    "物流",
    "口感",
    "味道",
    "日期",
    "新鲜",
    "牛奶",
    "奶",
    "好喝",
    "难喝",
    "孩子",
    "老人",
    "满意",
    "喜欢",
    "性价比",
    "价格",
    "实惠",
    "营养",
    "浓",
    "香",
    "甜",
    "破损",
    "漏",
    "生产",
    "保质期",
    "回购",
    "购买",
    "发货",
    "快递",
    "收到",
    "品质",
)

STRONG_COMMENT_HINTS = (
    "包装",
    "物流",
    "口感",
    "味道",
    "新鲜",
    "好喝",
    "难喝",
    "孩子",
    "老人",
    "满意",
    "喜欢",
    "性价比",
    "实惠",
    "营养",
    "浓",
    "香",
    "甜",
    "破损",
    "漏",
    "回购",
    "购买",
    "快递",
    "收到",
    "品质",
    "划算",
    "便宜",
)


URL_RE = re.compile(r"(?:https?://|www\.)\S+|[\w.-]+\.(?:com|cn|net|org|top|shop|xyz|vip)\S*", re.I)
PHONE_RE = re.compile(r"(?<!\d)(?:\+?86[-\s]?)?1[3-9]\d{9}(?!\d)")
LANDLINE_RE = re.compile(r"(?<!\d)0\d{2,3}[-\s]?\d{7,8}(?!\d)")
ID_CARD_RE = re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)")
LONG_NUMBER_RE = re.compile(r"(?<!\d)\d{8,}(?!\d)")
MASKED_ID_RE = re.compile(r"(?<!\w)[\w\u4e00-\u9fff./-]{0,4}\*{1,3}[\w\u4e00-\u9fff./-]{0,4}(?!\w)")
TIME_RE = re.compile(r"\b\d{1,2}:\d{2}(?::\d{2})?\b")
SPEED_RE = re.compile(r"\b\d+(?:\.\d+)?\s*(?:KB|MB)/s\b", re.I)
PRICE_RE = re.compile(r"[¥￥]\s*\d+(?:\.\d+)?|(?<!\w)\d+(?:\.\d+)?\s*元")
REL_TIME_RE = re.compile(r"\b\d+\s*(?:秒|分钟|小时|天|个月|月|年)\s*前\b")
ADDRESS_RE = re.compile(
    r"[\u4e00-\u9fff]{2,}(?:省|自治区|市|区|县|镇|乡|街道|路|街|巷|小区|村|号楼|单元|室)"
)
LEADING_META_RE = re.compile(
    r"^(?:i\s*)?(?:有用\s*)?(?:\+?\d+\s*)*(?:[\w\u4e00-\u9fff./-]{0,4}\*{1,3}[\w\u4e00-\u9fff./-]{0,4}\s*)+"
    r"(?:(?:\d+\s*)?(?:秒|分钟|小时|天|个月|月|年)前\s*)?"
)
LEADING_VARIANT_RE = re.compile(
    r"^(?:[\w.-]*\d+(?:\.\d+)?\s*(?:ml|mL|ML|l|L|g|G|kg|KG|克|盒|瓶|袋|箱|包|支|罐|提|杯|片|条|斤|升)[\w*/×xX.-]*\s*)+"
)
COUNT_TAG_RE = re.compile(r"^[\u4e00-\u9fff]{2,8}\s+\d+(?:\.\d+)?万?\+?$")
PRODUCT_TITLE_RE = re.compile(
    r"(?:蒙牛|特仑苏|伊利|新希望|悦鲜活|纯牛奶|早餐奶|酸奶|纯甄|牛乳|调制乳|灭菌乳).{0,30}"
    r"(?:\d+(?:\.\d+)?\s*(?:ml|mL|ML|g|G|kg|KG|克|盒|瓶|袋|箱|包|升)|全脂|低脂|脱脂|有机|高钙)"
)
DATE_OR_SALES_PAGE_RE = re.compile(
    r"^(?:\d+\s*(?:秒|分钟|小时|天|月)前?有新增(?:好评)?|近\d+|预计\d+月|\d+月日期|新品|赠)"
)


def read_text(path: Path) -> tuple[str, str]:
    data = path.read_bytes()
    for encoding in ENCODINGS:
        try:
            return data.decode(encoding), encoding
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace"), "utf-8-replace"


def normalize_space(text: str) -> str:
    text = text.replace("\ufeff", " ")
    text = text.replace("\u3000", " ")
    text = re.sub(r"[\t\r\f\v]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def split_candidates(line: str) -> list[str]:
    line = normalize_space(line)
    if not line:
        return []
    parts = re.split(r"\s*\|\s*", line)
    if len(parts) == 1:
        return [line]
    candidates: list[str] = []
    for part in parts:
        part = normalize_space(part)
        if part:
            candidates.append(part)
    return candidates


def strip_personal_info(text: str) -> str:
    text = URL_RE.sub(" ", text)
    text = PHONE_RE.sub(" ", text)
    text = LANDLINE_RE.sub(" ", text)
    text = ID_CARD_RE.sub(" ", text)
    text = re.sub(r"(?:微信|VX|vx|QQ|qq|电话|手机|联系方式)[:：]?\s*[\w.-]{4,}", " ", text)
    text = ADDRESS_RE.sub(" ", text)
    text = LONG_NUMBER_RE.sub(" ", text)
    return normalize_space(text)


def cut_page_tail(text: str) -> str:
    padded = f" {text} "
    cut_at: int | None = None
    for marker in PAGE_CUT_MARKERS:
        idx = padded.find(marker)
        if idx > 0:
            cut_at = idx if cut_at is None else min(cut_at, idx)
    if cut_at is not None:
        return normalize_space(padded[:cut_at])
    return text


def strip_prefix_noise(text: str) -> str:
    previous = None
    current = text
    while current != previous:
        previous = current
        current = LEADING_META_RE.sub("", current).strip()
        current = REL_TIME_RE.sub(" ", current).strip()
        current = TIME_RE.sub(" ", current).strip()
        current = SPEED_RE.sub(" ", current).strip()
        current = PRICE_RE.sub(" ", current).strip()
        current = LEADING_VARIANT_RE.sub("", current).strip()
        current = re.sub(r"^(?:i|有用|\+\d+|\d+)\s+", "", current).strip()
    return normalize_space(current)


def page_noise_score(text: str) -> int:
    return sum(1 for term in PAGE_NOISE_TERMS if term in text)


def looks_like_product_or_page(text: str) -> bool:
    if not text:
        return True
    if text in PAGE_EXACT_TERMS or text in DEFAULT_REVIEW_TERMS:
        return True
    if any(term in text for term in PAGE_EXACT_TERMS) and not any(hint in text for hint in STRONG_COMMENT_HINTS):
        return True
    if COUNT_TAG_RE.match(text):
        return True
    if re.fullmatch(r"[\d+()./ -]+", text):
        return True
    if PRICE_RE.fullmatch(text) or TIME_RE.fullmatch(text) or SPEED_RE.fullmatch(text):
        return True
    if REL_TIME_RE.fullmatch(text):
        return True
    if MASKED_ID_RE.fullmatch(text) or MASKED_ID_RE.search(text):
        return True
    if "此用户" in text and ("好评" in text or "未填写" in text):
        return True
    if any(term in text for term in ("很多买家表示", "不少买家", "买家称赞", "该牛奶", "该产品")):
        return True
    if (
        text.startswith("商家")
        or text.startswith("店家")
        or "商家回复" in text
        or "商家回应" in text
        or "店家回复" in text
    ):
        return True
    if "分享" in text and ("点赞" in text or "评论" in text or "已购" in text or "超赞" in text):
        return True
    if text.startswith("品牌") and not any(hint in text for hint in STRONG_COMMENT_HINTS):
        return True
    if DATE_OR_SALES_PAGE_RE.search(text) and not any(hint in text for hint in STRONG_COMMENT_HINTS):
        return True
    if PRODUCT_TITLE_RE.search(text) and not any(hint in text for hint in STRONG_COMMENT_HINTS):
        return True
    if page_noise_score(text) >= 1 and not any(hint in text for hint in STRONG_COMMENT_HINTS):
        return True
    if page_noise_score(text) >= 4:
        return True
    if len(text) > 120 and page_noise_score(text) >= 2 and not any(hint in text for hint in COMMENT_HINTS):
        return True
    return False


def chinese_char_count(text: str) -> int:
    return len(re.findall(r"[\u4e00-\u9fff]", text))


def clean_candidate(candidate: str) -> str | None:
    text = normalize_space(candidate)
    if not text:
        return None

    text = strip_personal_info(text)
    text = cut_page_tail(text)
    text = strip_prefix_noise(text)

    # Remove masked user ids that remain in the middle of a mixed metadata/comment segment.
    text = MASKED_ID_RE.sub(" ", text)
    text = strip_prefix_noise(text)

    # Drop short platform labels and score/category fragments before checking comment quality.
    text = re.sub(r"\b(?:App|DR|CBP)\b", " ", text, flags=re.I)
    text = normalize_space(text)
    text = text.strip(" |，,。.!！?？、:：;；-+()（）[]【】\"'")
    text = text.replace("五星好评", "满意").replace("总体好评", "总体满意")
    text = re.sub(r"(?:加入购物车|购物车|图/视频|展开|回复|客服|好评|差评|全部)", " ", text)
    text = re.sub(r"(?:已填写具体收货地址|具体收货地址)[，,;； ]*", "", text)
    text = normalize_space(re.sub(r"\bi\b$", "", text)).strip(" |，,。.!！?？、:：;；-+()（）[]【】\"'")

    if not text or looks_like_product_or_page(text):
        return None

    cjk = chinese_char_count(text)
    if cjk < 3:
        return None
    if cjk < 6 and not any(hint in text for hint in COMMENT_HINTS):
        return None

    # Very long lines that still contain page chrome are usually OCR/scrape residue.
    if len(text) > 260 and page_noise_score(text) >= 2:
        return None

    return text


def dedupe_key(text: str) -> str:
    key = normalize_space(text).casefold()
    key = re.sub(r"[^\w\u4e00-\u9fff]+", "", key)
    return key


def process_file(path: Path, out_path: Path) -> dict[str, object]:
    text, encoding = read_text(path)
    raw_lines = text.splitlines()
    candidates: list[str] = []

    for raw_line in raw_lines:
        for candidate in split_candidates(raw_line):
            cleaned = clean_candidate(candidate)
            if cleaned:
                candidates.append(cleaned)

    seen: set[str] = set()
    cleaned_lines: list[str] = []
    for item in candidates:
        key = dedupe_key(item)
        if key and key not in seen:
            seen.add(key)
            cleaned_lines.append(item)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(cleaned_lines) + ("\n" if cleaned_lines else ""), encoding="utf-8")

    return {
        "原始文件名": path.name,
        "原始行数": len(raw_lines),
        "清洗后行数": len(cleaned_lines),
        "去重删除数量": len(candidates) - len(cleaned_lines),
        "输出文件路径": str(out_path),
        "_encoding": encoding,
    }


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: py process_comments.py <folder>", file=sys.stderr)
        return 2

    base = Path(sys.argv[1]).resolve()
    if not base.is_dir():
        print(f"Folder not found: {base}", file=sys.stderr)
        return 2

    processed = base / "processed"
    processed.mkdir(exist_ok=True)

    source_files = sorted(p for p in base.glob("*.txt") if p.is_file())
    reports: list[dict[str, object]] = []
    merged: list[str] = []
    global_seen: set[str] = set()

    for source in source_files:
        out_path = processed / source.name
        report = process_file(source, out_path)
        reports.append(report)
        for line in out_path.read_text(encoding="utf-8").splitlines():
            key = dedupe_key(line)
            if key and key not in global_seen:
                global_seen.add(key)
                merged.append(line)

    report_path = processed / "processing_report.csv"
    with report_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=("原始文件名", "原始行数", "清洗后行数", "去重删除数量", "输出文件路径"),
        )
        writer.writeheader()
        for report in reports:
            writer.writerow({k: report[k] for k in writer.fieldnames})

    merged_path = processed / "all_comments_merged.txt"
    merged_path.write_text("\n".join(merged) + ("\n" if merged else ""), encoding="utf-8")

    sample_path = processed / "sample_comments.txt"
    sample_path.write_text("\n".join(merged[:200]) + ("\n" if merged[:200] else ""), encoding="utf-8")

    print(f"source_files={len(source_files)}")
    print(f"processed_dir={processed}")
    print(f"report={report_path}")
    print(f"merged={merged_path}")
    print(f"sample={sample_path}")
    print(f"cleaned_lines_total={sum(int(r['清洗后行数']) for r in reports)}")
    print(f"merged_unique_lines={len(merged)}")
    print(f"duplicate_removed_total={sum(int(r['去重删除数量']) for r in reports)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
